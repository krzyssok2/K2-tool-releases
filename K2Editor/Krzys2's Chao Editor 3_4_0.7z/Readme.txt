Krzys2's Chao Editor
Version 3.4.0 (May 27, 2024)

Copyright � 2024 Krzys2 (Ksystof Stanislav Sokolovski)
All rights reserved.

------------------------------------------------
1. Introduction
------------------------------------------------

This application was developed by Krzys2 to modify Chao garden data. Biggest inspiration for this project was Fusion's chao editor, so similar layout, wording and similar things might be present.
Krzys2's Chao Editor doesn't serve as replacement for Fusion's chao editor, but exists as an alternative for mod users who still want to use editor.
Krzys2's Chao Editor was created to be as mod friendly tool as possible, that is why it shouldn't break mods nor mods should break the tool.
In addition to main game, this tool supports Chao World Extended and Enhanced Chao World mods, that is why, new options might appear if mods are detected.

------------------------------------------------
2. Features
------------------------------------------------

	� Support for all 3 games: Sonic adventure 2004, Sonic Adventure DX, Sonic adventure 2/battle
	� The chao transporter like UI
	� Responsive UI, with ability to rescale the window
	� x6 modify chao data
	� Ability to modify garden data
	� Chao World Extended support
	� Enhanced Chao World support
	� Always on top option
	� Dark/Light theme
	� Creation of custom themes
	� Editor serves as a hub for my other programs, which can be linked by placing all my other tools into Editor's exe folder and launched through editor

------------------------------------------------
3. Installationi
------------------------------------------------

1. You have to have .NET 8 Core installed on your computer from Microsoft

2. Extract files into desired folder

------------------------------------------------
4. Version History
------------------------------------------------

Version 1.0.0 (September 26, 2020)
  � First release of the program
  � Krzys2's Chao Editor

Version 1.0.1 (September 27, 2020)
  � Fixed some typos in tooltips
  � Fixed Lessons tab not updating at all
  � Fixed Lessons tab being stuck at slot 1
  � Simplified some XAML lines in code

Version 1.1.0 (October 4, 2020)

  � Fixed various tooltips errors
  � Fixed label typos in animal catergory
  � Added importing/exporting/exporting as a friend
  � Added original amy/knuckles/tails chao importation from japanese event
  � Added delete/copy/paste/cut of slots with quick shortcuts


Version 1.2.0 (October 11, 2020)

  � Added ability to create/use custom themes
  � Rewrote view only mode, making it not even attempt to mess with original values
  � Fixed animal behaviour descriptions(Seal and penguin)

Version 1.2.1 (October 13, 2020)

  � Fixed Piano/Organ from CWE being disabled on garden tab change on launch
  � Fixed garden unlocks disabling organ/piano
  � Fixed other bitwise functions in tabs: Animal Behaviours, Toys, Lessons, Garden

Version 1.3.0 (October 15, 2020)

  � Fixed labels having default wrong tooltip
  � Added lifetime to DNA
  � Added Support for CWE fruits being displayed
  � Added Support for CWE X grade being displayed
  � Added CWE accessories section to appearance tab(Acc 4 is not being displayed yet)
  � Changed toys tab to prizes
  � Added unlockable medals to prizes tab
  � Minor XAML optimization


Version 1.3.1 (October 25,2020)

  � Added a way to fix broken kindergarten slots/ chao in kindegerden bug in garden tab
  � Fixed none problems in seeds/fruits/hats tabs
  � Fixed garden tab dictionaries
  � Rewrote dictionary to short convert
  � Added bat to sa2b animal arms in appearance section(Invisible arms)

Version 2.0.0 (April 25, 2021)
  � Editor remake codewise to follow MVVM pattern and TONS of code optimization
  � Recheck Mod DLLS added in Hub tab(no restart needed if editor didnt detect mod)
  � SECW support added
  � Garden tab seperated into smaller tabs
  � Added garden timers to general garden tab
  � Added inventory to garden tab
  � Added CWE 9.2/9.3 new item support
  � Added Friendships tab(CWE only)
  � Added CWE palette feature
  � Added negativity and DC wings flags
  � Added SECW immortality/Hyper/Old hyper flag
  � Blackmarket rewritten(Code wise)
  � Added blackmarket reset Timer
  � Added new descriptions and fixed some minor errors
  � Changed jewel names to original names
  � Changed evolution type being sorted by aligment rather than id order
  � Added pearl unlock to prizes section(CWE only)
  � Added Wrench to prizes(CWE only)
  � Added "Check all tick to behaviours/prizes/lessons
  � Adjusted cancelation timer for the process(relaunch game too quick and editor wont recognise the game)
  � Fixed chao name bug where one symbol was recognised wrongly
  � Added new amazing custom icons for new tabs buttons by AWildDayDreamer!
  � Tweaked how Editor works while being in background not focused(less functions run and writting into the game functions are disabled)
  � Tweaked scrollbars, now every tab has its own scrollbar!(if you scroll in one, it wont scroll in other)

Version 2.0.1 (May 3, 2021)
  � Fixed editor not recognizing SADX 2004 and SADX Steam
  � Fixed editor getting confused and reseting immortality in secw section
  � Added failsafe to configuration file

Version 2.1.0 (July 20, 2021)
  � Added CWE 9.4 Support(New BM, Specials tab, Inventory changes)
  � CWE accessories tab rewritten to fit new version
  � Added Chao friendship caching(Chao relationships from another save if were cached gonna be displayed in current save), cache updates every time you open chao tab/relationships tab
  � Configuration file remade(old one wont work)
  � CWE accessories tab rewritten to fit new version
  � Refactored 2-4 bytes conversion
  � Refactored bit flags like animal behaviours/toys/lessons etc.
  � Customization code behind rewritten and optimized
  � Added Launcher.exe error (confirmation that its not supported)
  � Fixed some CWE features appearing in SADX games when they are not supposed to
  � Added Version display in editor name
  � Mod check is done on seperate thread(UI thread wont be blocked, no editor freeze)

Version 2.1.1 (August 10, 2021)
  � Fixed bug where launcher.exe error was shown when original launcher.exe was launched
  � Fixed Editor not resetting process if you closed and opened game too fast
  � Fixed Editor not resetting when two games are opened and you close one which editor is connected to

Version 2.2.0 (January 21, 2022)
  � Fixed various tooltip mistakes
  � Added support section to Hub panel
  � Added a fix for distribution button
  � Added names to chao colors for CWE
  � Added texture names for chao textures
  � Added 6 more fruit slots
  � Set all option separated into another expander on top of the page
  � Added clear menu for clearing fruits for specific gardens
  � Fixed names with spaces
  � Huge code cleanup
  � Adjusted loved/hated fruit dictionary, now including fruits chao hate!
  � Fixed view only mode event not triggering on loaded panels

Version 2.2.1 (January 21, 2022)
  � Fixed inventory panel crashing the editor if running without CWE

Version 2.3.0 (April 10, 2022)
  � CWE 9.5 support(Expanded inventory, name expansion, chao tree)
  � Adjustment to DLL detection - editor waits till all dlls are loaded(Thanks Exant!)
  � Tooltip adjustments and grammar fixes
  � Various optimization and code cleanup
  � Fixed some fruit controls being mixed up
  � Fixed rings going out of allowed bounds
  � Fixed some fruit controls being mixed up

Version 2.4.0 (August 24, 2022)
  � Dictionaries cleanup
  � Constant fields cleanup
  � Removed brightfix from CWE settings
  � Removed export as a guest feature
  � Added shiny settings in appearance category

Version 2.4.1 (August 26, 2022)
  � Fixed dictionary mismatch between palletes and accessories

Version 2.5.0 (September 22, 2022)
  � Added CWE mods support: Fruits/Hats/Accessories/Seeds/Trees
  � Added an overlay prompting users that Chao World is not loaded
  � Added an option to disable Chao World not loaded overlay
  � Fixed animals/items spawning underground(Now some of them might fall from the sky)

Version 3.0.0 (August 24, 2023)
  � Full editor rewrite from .Net Framework 4.5 to .Net Core 7 with Community Toolkit NuGet
  � Optimized game detection system
  � Optimized mod detection system
  � HEAVILY Optimized flag detection and adjustment system(especially from code readibility)
  � Added new Debug tab(With new icon by Chao Professor!)
  � Moved debug features from Garden General to Garden Debug tab
  � Added ability to force moods and states on chao or all chao in debug mode
  � Overhauled how editor buttons look, using chao font
  � Added tabbed windows for sub tabs
  � Adjusted Personality tab - moods and states are separated now
  � Adjusted Behaviours tab - SA2B and SADX are now separated into sub tabs
  � Adjusted Appearance tab - Vanilla, CWE and SECW have their own sub tabs
  � Adjusted DNA tabs - DNA1 and DNA2 was merged into one tab called "Genetics", those 2 separate tabs act like subtabs
  � Adjusted Relationships tab - Moved Character bonds from General to Relationship tab, now 3 sub tabs are present: sa2b, sadx, CWE chao
  � Adjusted animal parts for new CWE system - custom animals are moved to SA2B parts from SADX
  � Adjusted SA2B unlocks in Garden General tab, to be sorted by garden and by type
  � Added CWE instruments to Lessons tab
  � Added more theming options
  � Added "Unlock all races" option for SA2B
  � Added support for new CWE Custom chao evolutions
  � Added Function to quickly change move chao down or up by the slot with commands like CTRL+ w and CRL + s or by right click
  � Added some silly Easter Eggs
  � Added abillity for Yami icon to blink :)
  � Added support for custom game names in configuration(ONLY FOR ADVANCED USERS, USE AT YOUR OWN RISK)
  � Added set all option to some tabs(which previously was only available if you clicked "Made by krzys2" 10 times for debug reasons)
  � Fixed Appearance tab having wrong dictionaries
  � Removed functionality of blocking users from selecting CWE special fruits like hyper fruits
  � Removed Stats limit, now can go to max 65535

Version 3.0.1 (August 25, 2023)
  � Added error handling, log creation about crash

Version 3.0.2 (August 26, 2023)
  � Fix stats and relationships override on launch

Version 3.0.3 (October 7, 2023)
  � Secret theme fix
  � Default configuration fix

Version 3.0.4 (October 25, 2023)
  � Fix "garden not loaded" overlay not disappearing in SADX2004

Version 3.1.0 (December 3, 2023)
  � Update to .Net8
  � Rewrote write to game memory logic - Write calls are disabled when read tick is being executed
  � Disabled editor write calls when window is unfocused
  � Disabled editor write calls when editor is in view only mode

Version 3.1.1 (December 3, 2023)
  � Automatically generate configuration file if it is not present

Version 3.1.2 (December 13, 2023)
  � Optimized comboboxes

Version 3.1.3 (February 14, 2024)
  � Fix custom CWE evolutions

Version 3.2.0 (April 13, 2024)
  � Added CWE Lens support in personality tab(Thanks Exant for support)
  � Added Auto update

Version 3.2.1 (April 23, 2024)
  � Fix raccoon tail not being shown or available in appearance tab
  � Fix debug tab not being shown

Version 3.2.2 (June 1, 2024)
  � Fix meet field not being populated

Version 3.3.0 (December 8, 2024)
  � CWE hat support(Personality/Hats tab)
  � Fix context menu for special themes
  � Fix typo for skunk description in behaviours tab

Version 3.4.0 (May 27, 2025)
  � Added CWE API animal support(available with CWE version 9.5.3.6 or newer)

------------------------------------------------
5. Contact
------------------------------------------------

If you want to report bugs or give feedback you can send me message on Email, Chao Island forum or on GameBanana
Email: krzys1999@list.ru
Chao Island forum profile: https://chao-island.com/forum/memberlist.php?mode=viewprofile&u=27157&sid=b8a544eb1d874f6264add2397e02b69b
GameBanana profile: https://gamebanana.com/members/1691941
Discord: .krzys2

------------------------------------------------
6. Credits
------------------------------------------------

Krzys2 - I have created Krzys2's Chao Editor
Massive thanks to AWildDaydreamer for creating awesome icons for the buttons which really brings editor in game feel!
Thanks to Fusion for being inspiration to create this tool, for his awesome Fusion's chao editor and all the documentation
Thanks to Exant for providing structures data and answering my questions
Thanks to Mooncow for creating awesome Chao Island community and wikia.
Thanks to Sonic Team for making SADX and SA2B, I wish more games with chao gardens would be created.

And thank you to whole Chao Island community and people who use my tools!

------------------------------------------------
7. License
------------------------------------------------

Chao font, chao background assets, animals photos copyright � SEGA 1999-2006.

Everything else like source code, resources and all included files are copyright � Krzys2. I reserve any and all rights. Krzys2's Chao Editor may only be destributed with permission from Krzys2
------------------------------------------------
Krzys2's Chao Editor is not supported by or associated with SEGA or Sonic Team. Chao, Sonic, the Sonic Adventure series, and the Sonic Advance series is � SEGA 1999-2006.
